#!/usr/bin/env python
import libsbml
import balancer
import copy
import SBtab
import kineticizer
import os
import sys
import misc
import tablib
import validatorSBtab
import SBtab_old

def parameter_balancing_wrapper(model_name):
    '''
    wrapper for the parameter balancing via the command line
    '''
    log_file = 'Parameter balancing log file of model %s\n\n'%(model_name)
    
    #1: open and prepare the files; then check for some rudimentary validity:
    #1.1: SBML model
    reader = libsbml.SBMLReader()
    try: sbml_file  = reader.readSBML(model_name)
    except: print 'The SBML file %s could not be found.'%(sbml_name)
    try: sbml_model = sbml_file.getModel()
    except:
        print 'The SBML file %s is corrupt. I quit.'%(sbml_name)
        sys.exit()
    valid_extension  = misc.validate_file_extension(model_name,'sbml')
    if not valid_extension:
        print 'The SBML file %s has not the correct xml extension. I quit.'%(model_name)
        sys.exit()

    pb = balancer.ParameterBalancing(sbml_model)

    #1.2: SBtab file
    sbtab_name = raw_input('\nPlease enter SBtab name (this is optional; you can also just hit enter to proceed without SBtab file):\n')
    
    if sbtab_name != '':
        try: sbtab_file = open(sbtab_name,'r')
        except:
            print 'The SBtab file "'"%s"'" could not be found. I quit.\n'%(sbtab_name)
            sys.exit()
        sbtab           = sbtab_file.read()
        valid_extension = misc.validate_file_extension(sbtab_name,'sbtab')
        if not valid_extension:
            print 'The SBtab file %s has not the correct tsv extension. I quit.'%(sbtab_name)
            sys.exit()
        try: delimiter_sbtab = misc.check_delimiter(sbtab)
        except: delimiter_sbtab = '\t'
        revoked_sbtab  = misc.revoke_sbtab(sbtab,delimiter_sbtab)
        use_header     = revoked_sbtab.split('\n')[0].split('\t')
        no_sbtab = False
    else: no_sbtab = True

    #1.3: Prior file        
    prior_name = raw_input('\nPlease enter prior file name (this is optional; you can also just hit enter to proceed with the default prior table):\n')
        
    if prior_name != '':
        try: prior_file = open(prior_name,'r')
        except:
            print 'The prior file %s could not be found.'%(prior_name)
            sys.exit()
        prior           = prior_file.read()
        valid_extension = misc.validate_file_extension(prior_name,'sbtab')
        if not valid_extension:
            print 'The prior file %s has not the correct tsv extension. I quit.'%(prior_name)
            sys.exit()
        delimiter_prior = misc.check_delimiter(prior)
        valid_prior     = misc.valid_prior(prior,delimiter_prior)
        if valid_prior != []:
            for element in valid_prior:
                log_file += str(element) +'\n'
    else:
        try: prior_file = open('./../static/files/default/prior.tsv','r')
        except:
            print 'The prior file %s could not be found. I quit.'%(prior_name)
            sys.exit()
        prior = prior_file.read()
        delimiter_prior = '\t'

    (priors,pseudos,pmin,pmax) = misc.extract_priorpseudos(prior,delimiter_prior)

    #1.4: Config file
    config_name = raw_input('\nPlease enter config file name (this is optional; you can also just hit enter to proceed with the default balancing configuration):\n')

    if config_name:
        try: config_file = open(config_name,'r')
        except: print 'The config file %s could not be found.'%(config_name)
        config      = config_file.read()
        if not valid_extension:
            print 'The config file %s has not the correct extension .tsv and will not be used for balancing.'%(config_name)
        delimiter_config = misc.check_delimiter(config)
        (parameter_dict,log) = misc.readout_config(config,delimiter_config)
        if log != []:
            for element in log:
                log_file += str(element) +'\n'
    else: parameter_dict = {}

    if no_sbtab:
        (header,rows) = pb.makeEmptySBtab(pmin,pmax,parameter_dict)
        revoked_sbtab = '\t'.join(header)+'\n'
        for row in rows:
            revoked_sbtab += '\t'.join(row)+'\n'
        delimiter_sbtab = '\t'
    else:
        (header,rows)  = pb.makeSBtab(revoked_sbtab,use_header,sbtab_name,'All organisms',43,pmin,pmax,parameter_dict)
        sbtabid2sbmlid = misc.id_checker(sbtab,sbml_model)
        if sbtabid2sbmlid != []:
            for element in sbtabid2sbmlid:
                log_file.append(element)
               

    if not 'Temperature' in parameter_dict.keys(): parameter_dict['Temperature'] = 37
    if not 'pH' in parameter_dict.keys(): parameter_dict['pH'] = 7
    if not 'standard chemical potential' in parameter_dict.keys(): parameter_dict['standard chemical potential'] = True
    if not 'catalytic rate constant geometric mean' in parameter_dict.keys(): parameter_dict['catalytic rate constant geometric mean'] = True
    if not 'Michaelis constant' in parameter_dict.keys(): parameter_dict['Michaelis constant'] = True
    if not 'activation constant' in parameter_dict.keys(): parameter_dict['activation constant'] = True
    if not 'inhibitory constant' in parameter_dict.keys(): parameter_dict['inhibitory constant'] = True
    if not 'concentration' in parameter_dict.keys(): parameter_dict['concentration'] = True
    if not 'concentration of enzyme' in parameter_dict.keys(): parameter_dict['concentration of enzyme'] = True
    if not 'equilibrium constant' in parameter_dict.keys(): parameter_dict['equilibrium constant'] = True
    if not 'substrate catalytic rate constant' in parameter_dict.keys(): parameter_dict['substrate catalytic rate constant'] = True
    if not 'product catalytic rate constant' in parameter_dict.keys(): parameter_dict['product catalytic rate constant'] = True
    if not 'forward maximal velocity' in parameter_dict.keys(): parameter_dict['forward maximal velocity'] = True
    if not 'reverse maximal velocity' in parameter_dict.keys(): parameter_dict['reverse maximal velocity'] = True
    if not 'chemical potential' in parameter_dict.keys(): parameter_dict['chemical potential'] = True
    if not 'reaction affinity' in parameter_dict.keys(): parameter_dict['reaction affinity'] = True

    print '\nFiles successfully read. Start balancing.\n'
    
    #2: Parameter balancing
    filled_rows = pb.fillSBtab(rows,priors,pseudos)
    (mean_vector,mean_vector_inc,c_post,c_post_inc,r_matrix,shannon,(header,rows),log) = pb.makeBalancing(parameter_dict,filled_rows,revoked_sbtab,pmin,pmax)

    #3: Postprocessing
    sbtabone   = "\n".join(["\t".join([str(x) for x in row]) for row in rows])
    sbtabtwo   = pb.checkForBlanks(sbtabone)
    sbtabthree = pb.mimicMean(sbtabtwo)
    sbtabfour  = sbtabthree.split('\n')
    
    print '\nAll reactions are balanced! Now inserting the laws and parameters into the model\n'

    #4: inserting parameters and kinetics into SBML model
    sbtab_cl       = SBtab_old.SBtabTable(sbtabfour,sbtab_name,'QuantityType')

    try: mode = parameter_dict['param']
    except: mode = 'hal'
    try: enzyme_prefac = parameter_dict['prefac']
    except: enzyme_prefac = True
    try: def_inh = parameter_dict['default_inh']
    except: def_inh = 'complete_inh'
    try: def_act = parameter_dict['default_act']
    except: def_act = 'complete_act'
    try: overwrite = parameter_dict['overwrite']
    except: overwrite = True
    kineticizer_cs = kineticizer.kineticizer_cs(sbml_model,sbtab_cl,mode,enzyme_prefac,def_inh,def_act,True)
    
    print '\nDone... now writing output files to disk\n\nGoodbye!\n\n'

    #5: Write SBtab and SBML model
    model_name = str(model_name)[:-4]
    new_sbtab_file = open(model_name+'_balanced.tsv','w')
    new_sbtab_file.write(sbtabtwo)
    new_sbtab_file.close()

    sbml_code = '<?xml version="1.0" encoding="UTF-8"?>\n' + sbml_model.toSBML()
    new_sbml_model = open(model_name+'_balanced.xml','w')
    new_sbml_model.write(sbml_code)
    new_sbml_model.close()

    try:
        os.remove('cpost.txt')
        os.remove('medians.txt')
    except: pass

if __name__ == '__main__':
    
    model_name = sys.argv[1]
    parameter_balancing_wrapper(model_name)
    '''
    try:
        sbtab_name = sys.argv[2]
        try:
            prior_name = sys.argv[3]
            try:
                config_name = sys.argv[4]
                parameter_balancing_wrapper(model_name,sbtab_name,prior_name,config_name)
            except:
                parameter_balancing_wrapper(model_name,sbtab_name,prior_name)
        except: 
            parameter_balancing_wrapper(model_name,sbtab_name)
    except:
        parameter_balancing_wrapper(model_name)
    '''


